package com.example.lakshmipathi.labsdemo;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{
    TextView topTest,areaTV;
    String area;
    DataBaseConnection dataBaseConnection;
    ArrayList<TestNames> arrayList=new ArrayList<TestNames>();
    ListViewAdapterTest adapter;
    SearchView searchView;
    ListView listView;
    Context context;
    String test;
    Double latitude,longitude;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        topTest=findViewById(R.id.textView);
        areaTV=findViewById(R.id.tool_text);
        listView=findViewById(R.id.listView);
        searchView=findViewById(R.id.searchView);
     /*   Intent in = getIntent();
        Bundle b = in.getExtras();
        latitude = b.getDouble("lat");
        longitude = b.getDouble("lng");*/
        new DBAccess().execute("");
        context=this;
        Intent i = getIntent();
        area = i.getStringExtra("selected");
        
        areaTV.setText(area);
        listView.setOnItemClickListener(            new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                new Thread(()-> {
                        /*try {
                            Geocoder gc = new Geocoder(TestActivity.this);
                            List<Address> addresses = gc.getFromLocationName(area, 5); // get the found Address Objects
                             for (Address a : addresses) {
                                if (a.hasLatitude() && a.hasLongitude()) {
                                    latitute=a.getLatitude();
                                    longitute=a.getLongitude();
                                }
                            }
                        } catch (IOException e) {
                            System.out.println(" "+e);
                        }*/
                        /*Bundle bundle = new Bundle();
                        test =((TextView)view.findViewById(R.id.textView)).getText().toString();
                        bundle.putDouble("lat",latitude);
                        bundle.putDouble("lng",longitude);
                        bundle.putString("test",test);*/
                        Intent intent = new Intent(TestActivity.this, ResultActivity.class);
                        //intent.putExtras(bundle);
                    intent.putExtra("selected", area);
                    startActivity(intent);
                }).start();
                Toast.makeText(context, "An item of the ListView is clicked.", Toast.LENGTH_LONG).show();
            }
        });
        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CLICK","CLICK");
                searchView.setOnQueryTextListener(TestActivity.this);

            }
        });
    }
   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        TextView tv = new TextView(this);
        tv.setText(area);
        tv.setTextColor(getResources().getColor(R.color.white));
        tv.setPadding(5, 0, 5, 0);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextSize(14);

        menu.add(0, 6, 1, area).setActionView(tv)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }*/

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String text = newText;
        adapter.filter(text);
        return false;
    }

    class DBAccess extends AsyncTask<String,String,String> {
        ProgressDialog dialog;

        @Override
        protected void onPreExecute(){
            dialog=ProgressDialog.show(TestActivity.this,"Wait..","Loading");
        }
        @Override
        protected void onPostExecute(String Result){
            dialog.dismiss();
       /* list_item= arrayList.toArray(new String[arrayList.size()]);
        //list_item=(String[])arrayList.toArray();
        Log.d("Area","List"+list_item);*/
            adapter=new ListViewAdapterTest(TestActivity.this,R.layout.activity_list,arrayList);
            listView.setAdapter(adapter);

        }
        @Override
        protected String doInBackground(String... strings) {
            dataBaseConnection =new DataBaseConnection();
            arrayList=dataBaseConnection.TestSearch(arrayList);
            return null;
        }
    }
}
