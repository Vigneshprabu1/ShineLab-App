package com.example.lakshmipathi.labsdemo;


class LatLng {
    Double lat;
    Double lng;
    public void setLatLng(Double latitute, Double longitute) {
        lat=latitute;
        lng=longitute;
    }
    public Double getLat(){
        return lat;
    }
    public Double getLng()
    {
        return lng;
    }
}
