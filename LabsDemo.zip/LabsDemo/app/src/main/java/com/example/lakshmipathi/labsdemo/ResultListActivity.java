package com.example.lakshmipathi.labsdemo;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ResultListActivity extends AppCompatActivity {
    DataBaseConnection dataBaseConnection;
    ArrayList<ResultList> arrayList = new ArrayList<ResultList>();
    ListView listView;
    ListViewAdapterResultList adapter;
    String labName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView=findViewById(R.id.listView);
        Intent i = getIntent();
        labName = i.getStringExtra("selected");
        new DBAccess().execute("");
    }

    class DBAccess extends AsyncTask<String, String, String> {
        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(ResultListActivity.this, "Wait..", "Loading");
        }

        @Override
        protected void onPostExecute(String Result) {
            dialog.dismiss();
            adapter = new ListViewAdapterResultList(ResultListActivity.this, R.layout.activity_list_result, arrayList);
            listView.setAdapter(adapter);
        }

        @Override
        protected String doInBackground(String... strings) {
            dataBaseConnection = new DataBaseConnection();
            arrayList = dataBaseConnection.ResultList(arrayList, labName);
            return null;
        }

    }
}
