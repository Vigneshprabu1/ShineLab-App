package com.example.lakshmipathi.labsdemo;



class TestNames {
    private final String testNames;
    TestNames(String testNames){
        this.testNames=testNames;
    }
    String getTestNames(){
        return testNames;
    }
}
