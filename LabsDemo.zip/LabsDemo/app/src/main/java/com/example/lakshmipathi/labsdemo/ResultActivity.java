package com.example.lakshmipathi.labsdemo;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ResultActivity extends AppCompatActivity {
    String area;
    TextView areaTV;
    LatLng latLng;
    Double latitude, longitude;
    DataBaseConnection dataBaseConnection;
    ArrayList<Results> arrayList = new ArrayList<Results>();
    ListView listView;
    ListViewAdapterResult adapter;
    SearchView searchView;
    Context context;
    String selectedList,test;

    //List<LatLng> ll;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        areaTV = findViewById(R.id.latlng);
        listView = findViewById(R.id.listView);
        searchView = findViewById(R.id.searchView);
       /* Intent i = getIntent();
        Bundle bundle = i.getExtras();
        latitude = bundle.getDouble("lat");
        longitude = bundle.getDouble("lng");
        test = bundle.getString("test");*/
        Intent i = getIntent();
        area = i.getStringExtra("selected");
        new DBAccess().execute("");


        context = this;
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("CLICK","ListView Clicked");
                Toast.makeText(context, "An item of the ListView is clicked.", Toast.LENGTH_LONG).show();
                selectedList =((TextView)view.findViewById(R.id.lab_name)).getText().toString();
                Intent intent = new Intent(ResultActivity.this, ResultListActivity.class);
                intent.putExtra("selected", selectedList);
                startActivity(intent);

            }
        });

    }

    class DBAccess extends AsyncTask<String,String,String>{
        ProgressDialog dialog;
        @Override
    protected void onPreExecute(){
        dialog= ProgressDialog.show(ResultActivity.this,"Wait..","Loading");
    }
    @Override
    protected void onPostExecute(String Result){
        dialog.dismiss();
       /* list_item= arrayList.toArray(new String[arrayList.size()]);
        //list_item=(String[])arrayList.toArray();
        Log.d("Area","List"+list_item);*/
        areaTV.setText(latitude+" "+longitude);
        adapter=new ListViewAdapterResult(ResultActivity.this,R.layout.activity_result_list,arrayList);
        listView.setAdapter(adapter);
    }
    @Override
    protected String doInBackground(String... strings) {
        Log.d("Area","List"+area);
        try {
            Geocoder gc = new Geocoder(ResultActivity.this);
            List<Address> addresses = gc.getFromLocationName(area, 10); // get the found Address Objects
            //ll= new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
            for (Address a : addresses) {
                Log.d("Area","List"+area);
                if (a.hasLatitude() && a.hasLongitude()) {
                    Log.d("Area","List"+area);
                   /* latLng.setLatLng(a.getLatitude(), a.getLongitude());
                    ll.add(latLng);*/
                    latitude=a.getLatitude();
                    longitude= a.getLongitude();
                    Log.d("ll", "geoFinder: "+latitude+""+longitude);
                }
            }
//migrate();
        } catch (IOException e) {
            System.out.println(" " + e);
        }
        dataBaseConnection =new DataBaseConnection();
        arrayList=dataBaseConnection.Results(arrayList,latitude,longitude,test);
        return null;
    }

}

}
