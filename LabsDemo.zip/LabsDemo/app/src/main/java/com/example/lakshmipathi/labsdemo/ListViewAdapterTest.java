package com.example.lakshmipathi.labsdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

class ListViewAdapterTest extends ArrayAdapter<TestNames> {
    Context context;
    int id;
    List<TestNames> testNamesList;
    ArrayList<TestNames> arrayList=new ArrayList<TestNames>();

    public ListViewAdapterTest(Context context, int activity_list, List<TestNames> testNamesList) {
        super(context,activity_list,testNamesList);
    this.context=context;
    id=activity_list;
    this.testNamesList=testNamesList;
    this.arrayList.addAll(testNamesList);
    }
    static class ViewHolder {
        public TextView textview;
    }
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(id, parent, false);
            ListViewAdapterTest.ViewHolder viewHolder = new ListViewAdapterTest.ViewHolder();
            viewHolder.textview = (TextView) rowView.findViewById(R.id.textView);
            rowView.setTag(viewHolder);
        }
        ListViewAdapterTest.ViewHolder holder = (ListViewAdapterTest.ViewHolder) rowView.getTag();
        holder.textview.setText(testNamesList.get(position).getTestNames());
        return rowView;
    }
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        testNamesList.clear();
        if (charText.length() == 0) {
            testNamesList.addAll(arrayList);
        } else {
            for (TestNames wp : arrayList) {
                if (wp.getTestNames().toLowerCase(Locale.getDefault()).contains(charText)) {
                    testNamesList.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }
}
