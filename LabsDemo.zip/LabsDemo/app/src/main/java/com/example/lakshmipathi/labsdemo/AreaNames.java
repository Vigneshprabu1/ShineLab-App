package com.example.lakshmipathi.labsdemo;
class AreaNames {
    String areaNames;
    public AreaNames(String area) {
        this.areaNames=area;
    }
    public String getAreaNames(){
        return areaNames;
    }
}
