package com.example.lakshmipathi.labsdemo;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChooseActivity extends AppCompatActivity implements View.OnClickListener{
    Button labs,doctor;
    String area;
    Double longitude,latitude;
    LatLng latLng;
    ArrayList<LatLng> ll=new ArrayList<LatLng>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        labs=findViewById(R.id.labs);
        doctor=findViewById(R.id.doctor);
        Intent i = getIntent();
        area = i.getStringExtra("selected");
//geoFinder();
/*        Intent in = getIntent();
        Bundle b = in.getExtras();
       latitude = b.getDouble("lat");
       longitude = b.getDouble("lng");*/
        labs.setOnClickListener(this);
        doctor.setOnClickListener(this);
    }
/*void geoFinder(){
        latLng=new LatLng();
    Log.d("Area","List"+area);
    try {
        area="T Nagar";
        Geocoder gc = new Geocoder(ChooseActivity.this);
        List<Address> addresses = gc.getFromLocationName(area, 5); // get the found Address Objects
        ll= new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
        for (Address a : addresses) {
            Log.d("Area","List"+area);
            if (a.hasLatitude() && a.hasLongitude()) {
                Log.d("Area","List"+area);
                latLng.setLatLng(a.getLatitude(), a.getLongitude());
                ll.add(latLng);
                    latitude=a.getLatitude();
                    longitude= a.getLongitude();
                Log.d("ll", "geoFinder: "+latitude+""+longitude);
            }
        }
//migrate();
    } catch (IOException e) {
        System.out.println(" " + e);
    }
}*/

    @Override
    public void onClick(View v) {
        /*Bundle bundle = new Bundle();
        Intent intent = new Intent(ChooseActivity.this, TestActivity.class);
        bundle.putDouble("lat",latLng.getLat());
        bundle.putDouble("lng",latLng.getLng());
        intent.putExtras(bundle);
        startActivity(intent);*/
        Log.d("Area","List"+area);
        Intent intent = new Intent(ChooseActivity.this, TestActivity.class);
        intent.putExtra("selected", area);
        startActivity(intent);
    }
}
