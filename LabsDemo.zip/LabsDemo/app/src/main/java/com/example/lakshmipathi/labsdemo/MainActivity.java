package com.example.lakshmipathi.labsdemo;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//public class MainActivity extends AppCompatActivity implements LocationListener,SearchView.OnQueryTextListener,View.OnClickListener {
    public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener,View.OnClickListener {

    String areaSV;
    Context context;
    ListView listView;
    SearchView searchView,search;
    ListViewAdapterArea adapter;
    ArrayList<AreaNames> arrayList=new ArrayList<AreaNames>();
    RelativeLayout relativeSelect,relativeSelectView;
    Button button1,button2,button3,button4,button5,button6,button7,button8,button9,proceed;
    DataBaseConnection dataBaseConnection;
    LocationManager locationManager;
    ImageButton currentLocation;
    Double latitude,longitude;
    LocationActivity locationActivity;
    LatLng latLng;
    ArrayList<LatLng> ll=new ArrayList<LatLng>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        relativeSelect=findViewById(R.id.select);
        relativeSelectView=findViewById(R.id.selectView);

        search= findViewById(R.id.search);
        listView = findViewById(R.id.list_item);
        searchView = findViewById(R.id.searchView);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button8=findViewById(R.id.button8);
        button9=findViewById(R.id.button9);
        proceed=findViewById(R.id.button10);
        currentLocation = findViewById(R.id.currentLocation);

        context = this;

        new DBAccess().execute("");

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                        Toast.makeText(context, "An item of the ListView is clicked.", Toast.LENGTH_LONG).show();
                        areaSV = ((TextView) view.findViewById(R.id.textView)).getText().toString();
                        relativeSelectView.setVisibility(View.INVISIBLE);
                        relativeSelect.setVisibility(View.VISIBLE);
                    }
                });

        search.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        Log.d("CLICK","CLICK");
                        relativeSelect.setVisibility(View.INVISIBLE);
                        relativeSelectView.setVisibility(View.VISIBLE);
                        searchView.setOnQueryTextListener(MainActivity.this);
            }
        });
      /* currentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CLICK","CLICK");
                getLocation();
            }
        });*/
        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        search.setIconified(true);
                        Log.d("Area","List"+areaSV);
                   // geoFinder();
                Intent i = new Intent(MainActivity.this, ChooseActivity.class);
                i.putExtra("selected", areaSV);
                startActivity(i);
              /*latLng=new LatLng();
                locationActivity=new LocationActivity(areaSV,MainActivity.this,latLng);
                locationActivity.geoFinder();
                longitude=latLng.getLng();
                latitude=latLng.getLat();
                Log.d("CLICK","CLICKmigrate");
                Bundle bundle = new Bundle();
                Intent intent = new Intent(MainActivity.this, ChooseActivity.class);
                bundle.putDouble("lat",latitude);
                bundle.putDouble("lng",longitude);
                intent.putExtras(bundle);
                startActivity(intent);*/

            }
        });
        //latLng=new LatLng();
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);

    }
    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String text = newText;
        adapter.filter(text);
        return false;
    }
    @Override
    public void onClick(final View v) {
        search.setIconified(true);
        Button b=(Button)v;
        areaSV = b.getText().toString();

                Log.d("Area","List"+areaSV);

                //getLocation();
                Intent i = new Intent(MainActivity.this, ChooseActivity.class);
                i.putExtra("selected", areaSV);
                startActivity(i);
                //geoFinder();
       /* latLng=new LatLng();
        locationActivity=new LocationActivity(areaSV,MainActivity.this,latLng);
        locationActivity.geoFinder();
        longitude=latLng.getLng();
        latitude=latLng.getLat();
        Log.d("CLICK","CLICKmigrate");
        Bundle bundle = new Bundle();
        Intent intent = new Intent(MainActivity.this, ChooseActivity.class);
        bundle.putDouble("lat",latitude);
        bundle.putDouble("lng",longitude);
        intent.putExtras(bundle);
        startActivity(intent)*/;
    }
   /*void getLocation() {
       Log.d("CLICK","CLICKlocation");
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);
        } catch (SecurityException e) {
            e.printStackTrace();
            System.out.println(""+e);
        }
    }

   @Override
    public void onLocationChanged(Location location) {
       latitude = location.getLatitude();
        longitude =location.getLongitude();
        migrate();

    }

    private void migrate() {
        Log.d("CLICK","CLICKmigrate");
        Bundle bundle = new Bundle();
        Intent intent = new Intent(MainActivity.this, ChooseActivity.class);
        bundle.putDouble("lat",latitude);
        bundle.putDouble("lng",longitude);
        intent.putExtras(bundle);
        startActivity(intent);

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(MainActivity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

*/

    class DBAccess extends AsyncTask<String,String,String>  {
    ProgressDialog dialog;

    @Override
    protected void onPreExecute(){
        dialog=ProgressDialog.show(MainActivity.this,"Wait..","Loading");
    }
    @Override
    protected void onPostExecute(String Result){
        dialog.dismiss();
       /* list_item= arrayList.toArray(new String[arrayList.size()]);
        //list_item=(String[])arrayList.toArray();
        Log.d("Area","List"+list_item);*/
        adapter=new ListViewAdapterArea(MainActivity.this,R.layout.activity_list,arrayList);
        listView.setAdapter(adapter);

    }
    @Override
    protected String doInBackground(String... strings) {
       dataBaseConnection =new DataBaseConnection();
       arrayList=dataBaseConnection.AreaSearch(arrayList);
       return null;
    }
}
}

