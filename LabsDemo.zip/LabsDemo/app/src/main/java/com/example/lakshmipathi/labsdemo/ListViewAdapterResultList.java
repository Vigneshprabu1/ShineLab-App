package com.example.lakshmipathi.labsdemo;


import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListViewAdapterResultList extends ArrayAdapter<ResultList> {
    Context context;
    int id;
    List<ResultList> resultsList;
    ArrayList<ResultList> arrayList=new ArrayList<ResultList>();

    public ListViewAdapterResultList(ResultListActivity context, int id, List<ResultList> arrayList) {
        super(context,id,arrayList);
        this.context=context;
        this.id=id;
        this.resultsList=arrayList;
        this.arrayList.addAll(resultsList);
    }
    static class ViewHolder {

        public ImageView lab_image;
        public TextView today;
        public TextView timing;
        public TextView all_timing;
        public TableRow hr;
        public TextView address;
        public Button call;
        public ImageView clock_image;
        public TableRow hr1,hr2;
        public TextView tests,test_name,test_cost;
        public Button all_test;
        public TextView facility;
        public TextView areaName,labName;
    }
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(id, parent, false);
            ListViewAdapterResultList.ViewHolder viewHolder = new ListViewAdapterResultList.ViewHolder();
            viewHolder.lab_image = (ImageView) rowView.findViewById(R.id.lab_image);
            viewHolder.clock_image = (ImageView) rowView.findViewById(R.id.clock_image);
            viewHolder.today = (TextView) rowView.findViewById(R.id.today);
            viewHolder.timing = (TextView) rowView.findViewById(R.id.timing);
            viewHolder.all_timing = (TextView) rowView.findViewById(R.id.all_timing);
            viewHolder.hr = (TableRow) rowView.findViewById(R.id.hr);
            viewHolder.address = (TextView) rowView.findViewById(R.id.address);
            //viewHolder.map = (fragment) rowView.findViewById(R.id.map);
            viewHolder.hr1 = (TableRow) rowView.findViewById(R.id.hr1);
            viewHolder.tests = (TextView) rowView.findViewById(R.id.tests);
            viewHolder.test_name = (TextView) rowView.findViewById(R.id.test_name1);
            viewHolder.test_cost = (TextView) rowView.findViewById(R.id.test_cost1);
            viewHolder.all_test=(Button)rowView.findViewById(R.id.all_test);
            viewHolder.call=(Button)rowView.findViewById(R.id.call);
            viewHolder.hr2 = (TableRow) rowView.findViewById(R.id.hr2);
            viewHolder.facility = (TextView) rowView.findViewById(R.id.facility);
            viewHolder.areaName = (TextView) rowView.findViewById(R.id.area_name);
            viewHolder.labName = (TextView) rowView.findViewById(R.id.lab_name);
            rowView.setTag(viewHolder);
        }
        ListViewAdapterResultList.ViewHolder holder = (ListViewAdapterResultList.ViewHolder) rowView.getTag();

        holder.timing.setText(resultsList.get(position).getTiming());
        holder.address.setText(resultsList.get(position).getAddress());
        holder.tests.setText(resultsList.get(position).getTest());
        holder.labName.setText(resultsList.get(position).getLabName());
        holder.areaName.setText(resultsList.get(position).getAreaName());
        holder.test_cost.setText(resultsList.get(position).getCost());
        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + resultsList.get(position).getMobileNumber()));
                    context.startActivity(callIntent);
                }
                catch (SecurityException e){
                    System.out.println(""+e.getMessage());
                }
            }
        });
        return rowView;
    }
}
