package com.example.lakshmipathi.labsdemo;

import android.content.Context;
import android.hardware.Camera;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListViewAdapterArea extends ArrayAdapter<AreaNames> {
    Context context;
    int id;
    List<AreaNames> areaNamesList;
    ArrayList<AreaNames> arraylist=new ArrayList<AreaNames>();

    public ListViewAdapterArea(@NonNull Context context, int resource, List<AreaNames>  areaNamesList) {
        super(context, resource, areaNamesList);
        this.context = context;
        id = resource;
        this.areaNamesList = areaNamesList;
        this.arraylist.addAll(areaNamesList);
    }
    static class ViewHolder {
        public TextView textview;
    }
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(id, parent, false);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.textview = (TextView) rowView.findViewById(R.id.textView);
            rowView.setTag(viewHolder);
        }
        ViewHolder holder = (ViewHolder) rowView.getTag();
        holder.textview.setText(areaNamesList.get(position).getAreaNames());
        return rowView;
    }
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        areaNamesList.clear();
        if (charText.length() == 0) {
            areaNamesList.addAll(arraylist);
        } else {
            for (AreaNames wp : arraylist) {
                if (wp.getAreaNames().toLowerCase(Locale.getDefault()).contains(charText)) {
                    areaNamesList.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }

}