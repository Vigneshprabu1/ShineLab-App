package com.example.lakshmipathi.labsdemo;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LocationActivity extends AppCompatActivity
{
    Double latitude,longitude;
    String areaSV;
    Bundle bundle;
    Context context;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        geoFinder();
    }

    void geoFinder(){
        areaSV="T Nagar";
        Log.d("Area","List"+areaSV);
         try {
            Geocoder gc = new Geocoder(LocationActivity.this);
            List<Address> addresses = gc.getFromLocationName(areaSV, 5); // get the found Address Objects
           // ll= new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
            for (Address a : addresses) {
                if (a.hasLatitude() && a.hasLongitude()) {
                    //latLng.setLatLng(a.getLatitude(), a.getLongitude());
                   // ll.add(latLng);
                    latitude=a.getLatitude();
                    longitude= a.getLongitude();
                    Log.d("ll", "geoFinder: "+latitude+""+longitude);
                }
            }
//migrate();
        } catch (IOException e) {
            System.out.println(" " + e);
        }

        //return latLng;
    }
    /*void migrate(){
        Log.d("Area","List"+areaSV);
        bundle = new Bundle();
        Intent intent = new Intent(LocationActivity.this, MainActivity.class);
        if (latitude!=0.0 && longitude!=0.0) {
            Log.d("Area","List"+areaSV);
            bundle.putDouble("lat", latitude);
            bundle.putDouble("lng", longitude);
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }*/
}
