package com.example.lakshmipathi.labsdemo;

import java.sql.Blob;

class ResultList {

    Blob labImage;
    String timing,address,test,mobileNumber,labName,areaName,cost;

    public ResultList(Blob labImage, String timing, String address, String test, String mobileNumber, String labName, String areaName, String cost) {
        this.labImage = labImage;
        this.timing = timing;
        this.address = address;
        this.test = test;
        this.mobileNumber = mobileNumber;
        this.labName = labName;
        this.areaName = areaName;
        this.cost = cost;
    }

    public Blob getLabImage() {
        return labImage;
    }

    public String getTiming() {
        return timing;
    }

    public String getAddress() {
        return address;
    }

    public String getTest() {
        return test;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getLabName() {
        return labName;
    }

    public String getAreaName() {
        return areaName;
    }

    public String getCost() {
        return cost;
    }
}
