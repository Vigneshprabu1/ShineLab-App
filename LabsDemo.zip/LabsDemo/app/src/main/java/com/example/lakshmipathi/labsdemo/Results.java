package com.example.lakshmipathi.labsdemo;

class Results {
    String result;
    String labName;
    String cost;
    String mobile_number;
    Double distance;
    public Results(String result,Double distance,String labName,String cost,String mobile_number) {
        this.result=result;
        this.distance=distance;
        this.labName=labName;
        this.cost=cost;
        this.mobile_number=mobile_number;
    }
    public String getResult(){
        return result;
    }
    public String getLabName(){
        return labName;
    }
    public String getCost(){
        return cost;
    }
    public Double getDistance(){
        return distance;
    }
    public String getMobile_number() {
        return mobile_number;
    }

}
