package com.example.lakshmipathi.labsdemo;


import android.hardware.Camera;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DataBaseConnection extends ArrayList<AreaNames>
{
    String errmsg;
    String area;
    String test;
    String result;
    Double distance;
    String lab_name,cost,mobile_number;
    String timing,address,name,mobileNumber,tests,areaName,costs;
    Blob labImage;
    Connection con = null;
    int count = 0;
    AreaNames areaNames;
    TestNames testNames;
    ResultList resultList;
    Results results;

    ArrayList<AreaNames> AreaSearch(ArrayList<AreaNames> arrayList){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.1.30:3306/Labs","root","admin");
            //con = DriverManager.getConnection("jdbc:mysql://192.168.43.113:3306/Labs","root","admin");
            try{
                String sql;
                sql = "SELECT city FROM area";
                PreparedStatement prest = con.prepareStatement(sql);
                ResultSet rs = prest.executeQuery();
                System.out.println("one");
                while (rs.next()){
                    area=rs.getString("city");
                    areaNames=new AreaNames(area);
                    arrayList.add(areaNames);
                    count++;
                    System.out.println(area);
                }
                System.out.println("Number of records: " + count);
                prest.close();
                con.close();
            }
            catch (SQLException s){
                System.out.println("SQL statement is not executed!");
                errmsg=errmsg+s.getMessage();
            }
        }
        catch (Exception e){
            e.printStackTrace();
            errmsg=errmsg+e.getMessage();
        }
        return arrayList;
    }


    public ArrayList<TestNames> TestSearch(ArrayList<TestNames> arrayList) {

        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.1.30:3306/Labs","root","admin");
            // con = DriverManager.getConnection("jdbc:mysql://192.168.43.113:3306/Labs","root","admin");
            try{
                String sql;
                sql = "SELECT labs_tests FROM test";
                PreparedStatement prest = con.prepareStatement(sql);
                ResultSet rs = prest.executeQuery();
                System.out.println("one");
                while (rs.next()){
                    test=rs.getString("labs_tests");
                    testNames=new TestNames(test);
                    arrayList.add(testNames);
                    count++;
                    System.out.println(test);
                }
                System.out.println("Number of records: " + count);
                prest.close();
                con.close();
            }
            catch (SQLException s){
                System.out.println("SQL statement is not executed!");
                errmsg=errmsg+s.getMessage();
            }
        }
        catch (Exception e){
            e.printStackTrace();
            errmsg=errmsg+e.getMessage();
        }
        return arrayList;
    }
    public ArrayList<Results> Results(ArrayList<Results> arrayList,Double lat,Double lng,String test) {

        System.out.println(lat +" "+lng);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.1.30:3306/Labs","root","admin");
            //con = DriverManager.getConnection("jdbc:mysql://192.168.43.113:3306/Labs","root","admin");
            try{
                /*this.latitute=latitute;
                this.longitute=longitute;*/
                String sql;
                PreparedStatement preparedStatement=con.prepareStatement("SET @latitute := "+lat);
                preparedStatement.executeQuery();
                PreparedStatement preparedStatement1=con.prepareStatement("SET @longitute := "+lng);
                preparedStatement1.executeQuery();
                //sql = "SELECT name,(6371 * acos( cos(radians(latitute)) * cos(radians(lat)) * cos(radians(lng) - radians(longitute)) + sin(radians(latitude)) * sin(radians(lat)))) as distance FROM latlng having distanse < 5 order by distance";
                sql="SELECT name,lab_name,mobile_number,cost,(6371 * 2 * ASIN(SQRT(POWER(SIN((@latitute - abs(lat)) * pi()/180 / 2), 2) + COS(@latitute * pi()/180 ) * COS(abs(lat) * pi()/180) * POWER(SIN((@longitute - lng) * pi()/180 / 2), 2) ))) as  distance FROM latlng  WHERE test= "+"\""+test+"\"" +" HAVING distance < 10 AND distance >=1  ORDER BY distance;";
                PreparedStatement prest = con.prepareStatement(sql);
                ResultSet rs = prest.executeQuery();
                System.out.println("one");
                while (rs.next()){
                    result=rs.getString("name");
                    distance=rs.getDouble("distance");
                    lab_name=rs.getString("lab_name");
                    mobile_number=rs.getString("mobile_number");
                    //test=rs.getString("test");
                    cost=rs.getString("cost");
                    results=new Results(result,distance,lab_name,cost,mobile_number);
                    arrayList.add(results);
                    count++;
                    System.out.println(result);
                    System.out.println(distance);
                    System.out.println(lab_name);
                    System.out.println(cost);
                }
                System.out.println("Number of records: " + count);
                prest.close();
                con.close();
            }
            catch (SQLException s){
                System.out.println("SQL statement is not executed!"+s.getMessage());
                errmsg=errmsg+s.getMessage();
            }
        }
        catch (Exception e){
            e.printStackTrace();
            errmsg=errmsg+e.getMessage();
        }
        return arrayList;
    }
    public ArrayList<ResultList> ResultList(ArrayList<ResultList> arrayList,String labName) {

        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.1.30:3306/Labs","root","admin");
            //con = DriverManager.getConnection("jdbc:mysql://192.168.43.113:3306/Labs","root","admin");
            try{
                String sql;
                sql="SELECT * from lab_details WHERE lab_name= "+"\""+labName+"\"";
                PreparedStatement prest = con.prepareStatement(sql);
                ResultSet rs = prest.executeQuery();
                System.out.println("one");
                while (rs.next()){
                    labImage=rs.getBlob("lab_image");
                    timing=rs.getString("timing");
                    address=rs.getString("address");
                    tests=rs.getString("test");
                    mobileNumber=rs.getString("mobile_number");
                    areaName=rs.getString("area");
                    name=rs.getString("lab_name");
                    costs=rs.getString("cost");

                    resultList=new ResultList(labImage,timing,address,tests,mobileNumber,areaName,name,costs);
                    arrayList.add(resultList);
                    count++;
                    System.out.println(mobile_number);
                    System.out.println(address);
                    System.out.println(name);
                    System.out.println(cost);
                }
                System.out.println("Number of records: " + count);
                prest.close();
                con.close();
            }
            catch (SQLException s){
                System.out.println("SQL statement is not executed!"+s.getMessage());
                errmsg=errmsg+s.getMessage();
            }
        }
        catch (Exception e){
            e.printStackTrace();
            errmsg=errmsg+e.getMessage();
        }
        return arrayList;
    }
}
