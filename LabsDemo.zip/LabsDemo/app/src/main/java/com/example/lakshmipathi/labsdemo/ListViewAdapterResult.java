package com.example.lakshmipathi.labsdemo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;



class ListViewAdapterResult extends ArrayAdapter<Results> {
    Context context;
    int id;
    List<Results> resultsList;
    ArrayList<Results> arrayList=new ArrayList<Results>();

    public ListViewAdapterResult(ResultActivity context, int id, ArrayList<Results> arrayList) {
        super(context,id,arrayList);
    this.context=context;
    this.id=id;
    this.resultsList=arrayList;
    this.arrayList.addAll(resultsList);
    }
    static class ViewHolder {
        public TextView area;
        public TextView distance;
        public TextView labName;
        public TextView cost;
        public Button call;
        public ImageView image,image1,image2,image3;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        Double value;
        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(id, parent, false);
            ListViewAdapterResult.ViewHolder viewHolder = new ListViewAdapterResult.ViewHolder();
            viewHolder.area = (TextView) rowView.findViewById(R.id.area);
            viewHolder.distance = (TextView) rowView.findViewById(R.id.distance);
            viewHolder.labName = (TextView) rowView.findViewById(R.id.lab_name);
            viewHolder.cost = (TextView) rowView.findViewById(R.id.cost);
            viewHolder.call=(Button)rowView.findViewById(R.id.call);
            viewHolder.image=(ImageView) rowView.findViewById(R.id.image);
            viewHolder.image1=(ImageView)rowView.findViewById(R.id.image1);
            viewHolder.image2=(ImageView) rowView.findViewById(R.id.image2);
            viewHolder.image3=(ImageView) rowView.findViewById(R.id.image3);


            rowView.setTag(viewHolder);
        }
        ListViewAdapterResult.ViewHolder holder = (ListViewAdapterResult.ViewHolder) rowView.getTag();
        holder.area.setText(resultsList.get(position).getResult());
        value=resultsList.get(position).getDistance();
        holder.distance.setText(String.format("%.2f", value));
        holder.labName.setText(resultsList.get(position).getLabName());
        holder.cost.setText(resultsList.get(position).getCost());
        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + resultsList.get(position).getMobile_number()));
                    context.startActivity(callIntent);
                }
                catch (SecurityException e){
                    System.out.println(""+e.getMessage());
                }
            }
        });
        return rowView;
    }
    /*public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        resultsList.clear();
        if (charText.length() == 0) {
            resultsList.addAll(arrayList);
        } else {
            for (Results wp : arrayList) {
                if (wp.getResult().toLowerCase(Locale.getDefault()).contains(charText)) {
                    resultsList.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }*/
}
