package com.shinelogics.booking;

import android.graphics.Color;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.Toast;
import android.content.Intent;

import com.harrywhewell.scrolldatepicker.DayScrollDatePicker;


public class BookAppointmentActivity extends AppCompatActivity  {

    ExpandableListView expandableListView;

    List<String> timing_shown;
    Map<String, List<String>> timing_hidden;
    ExpandableListAdapter listAdapter;

    private Button continues;



    @Override
    protected void onCreate(@Nullable  final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);



        continues = findViewById(R.id.button_continue);

        continues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookAppointmentActivity.this, BookAppointment2Activity.class);
                startActivity(intent);
            }
        });

        expandableListView = findViewById(R.id.expandable);
        fillData();
        listAdapter = new ExListAdapter(this, timing_shown, timing_hidden);
        expandableListView.setAdapter(listAdapter);

        expandableListView.setOnChildClickListener(new OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Toast.makeText(BookAppointmentActivity.this, timing_shown.get(groupPosition)+ " : " + timing_hidden.get(timing_shown.get(groupPosition)).get(childPosition)  , Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
    public void fillData(){
        timing_shown = new ArrayList<>();
        timing_hidden = new HashMap<>();

        timing_shown.add("Morning");
        timing_shown.add("Afternoon");
        timing_shown.add("Evening");

        List<String> morning = new ArrayList<>();
        List<String> afternoon = new ArrayList<>();
        List<String> evening = new ArrayList<>();

        morning.add("11.30AM");

        afternoon.add("12.00PM");
        afternoon.add("12.30PM");
        afternoon.add("01.00PM");
        afternoon.add("02.30PM");
        afternoon.add("03.00PM");

        evening.add("04.00PM");
        evening.add("04.30PM");
        evening.add("05.00PM");
        evening.add("05.30PM");
        evening.add("06.00PM");

        timing_hidden.put(timing_shown.get(0),morning);
        timing_hidden.put(timing_shown.get(1),afternoon);
        timing_hidden.put(timing_shown.get(2),evening);
    }

}

