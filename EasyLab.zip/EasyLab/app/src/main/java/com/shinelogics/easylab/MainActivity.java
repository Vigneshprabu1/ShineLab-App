package com.shinelogics.easylab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button signUp, signIn, signFacebook, signGoogle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signUp = findViewById(R.id.button_signup);
        signIn = findViewById(R.id.button_signin);
        signFacebook = findViewById(R.id.button_facebook);
        signGoogle = findViewById(R.id.button_google);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LandingActivity.class);
                startActivity(intent);
            }
        });
    }
}
