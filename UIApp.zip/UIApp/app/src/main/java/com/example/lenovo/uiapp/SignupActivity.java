package com.example.lenovo.uiapp;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;


public class SignupActivity extends AppCompatActivity {

    public static final String Name_extra="Name";
    public static final String Email_extra="Email_id";
    public static final String Pho_no_extra="phone_number";
    public static final String Password_extra="password";

    EditText  Name_Et,Email_id_Et,Phone_no_Et,Password_Et,ConformPassword_Et ;
    Button Verification;
    ProgressDialog progressDialog;
    private DatabaseReference mDatabase;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        auth =FirebaseAuth.getInstance();

        Name_Et = (EditText)findViewById(R.id.Name_et);
        Email_id_Et = (EditText)findViewById(R.id.emailid_ext);
        Phone_no_Et = (EditText)findViewById(R.id.ph_num);
        Password_Et = (EditText)findViewById(R.id.Pwd_et);
        ConformPassword_Et = (EditText)findViewById(R.id.cpwd_et);



        Verification =(Button)findViewById(R.id.Signup_btn);
        Verification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Number = Phone_no_Et.getText().toString().trim();
                String name = Name_Et.getText().toString().trim();
                String EmailID = Email_id_Et.getText().toString().trim();
                String Pass = Password_Et.getText().toString().trim();
                String conPwd = ConformPassword_Et.getText().toString().trim();

                auth.createUserWithEmailAndPassword(EmailID, Pass)
                        .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(SignupActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                //  progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(SignupActivity.this, "Authentication failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    startActivity(new Intent(SignupActivity.this, OTPActivity.class));
                                    finish();
                                }
                            }
                        });


                if (TextUtils.isEmpty(name)){
                    Name_Et.setError("Valid Name is required");
                    Name_Et.requestFocus();
                }
                else if (TextUtils.isEmpty(EmailID)){
                    Email_id_Et.setError("Valid EmailId is required");
                    Email_id_Et.requestFocus();

                }

                else if(TextUtils.isEmpty(Number) || Number.length() < 10){
                    Phone_no_Et.setError("Valid Number is required");
                    Phone_no_Et.requestFocus();
                }
                else if (TextUtils.isEmpty(Pass) || Pass.length() < 4){
                    Password_Et.setError("Password is required && minimum length of 4 characters");
                    Password_Et.requestFocus();
                }
                else if(!(Pass.equals(conPwd))){
                    ConformPassword_Et.setError("Paasword Miss match");
                    ConformPassword_Et.requestFocus();
                }

                else {



                    Intent intent = new Intent(SignupActivity.this,OTPActivity.class);
//                    progressDialog.setMessage("Please Wait....");
  //                  progressDialog.show();
                    intent.putExtra(Name_extra,name);
                    intent.putExtra(Email_extra,EmailID);
                    intent.putExtra(Pho_no_extra,Number);
                    intent.putExtra(Password_extra,Pass);
                    startActivity(intent);

                    return;
                }



            }
        });

    }

}
