package com.example.lenovo.uiapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Genaral_detailsActivity extends AppCompatActivity {

    TextView name,Email_id,ph_no,pwd;
    Button process_btn;
    private static final String TAG = "MainActivity";
    private DatabaseReference mDatabase;
    DatePickerDialog.OnDateSetListener mDateSetListener;
    TextView mDisplayDate;
    RadioButton radioSexButton;
    RadioGroup radioGroup;
    String gender = "";


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genaral_details);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        Intent i = getIntent();
        String n = i.getStringExtra(OTPActivity.Name2_extra);
        name = findViewById(R.id.Name);
        name.setText(n);

        String e = i.getStringExtra(OTPActivity.Email2_extra);
        Email_id = findViewById(R.id.emailid);
        Email_id.setText(e);

        String p = i.getStringExtra(OTPActivity.Password2_extra);
        pwd = findViewById(R.id.pass);
        pwd.setText(p);

        String ph = i.getStringExtra(OTPActivity.Pho_no2_extra);
        ph_no = findViewById(R.id.phonenumber);
        ph_no.setText(ph);


        mDisplayDate = (TextView) findViewById(R.id.tvDate);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Genaral_detailsActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog,
                        mDateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                String date = month + "/" + day + "/" + year;
                mDisplayDate.setText(date);
            }
        };




        radioGroup=(RadioGroup)findViewById(R.id.gender_Rg);

        process_btn=(Button)findViewById(R.id.process_btn);

        process_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId=radioGroup.getCheckedRadioButtonId();
                radioSexButton=(RadioButton)findViewById(selectedId);
                gender = radioSexButton.getText().toString();
                String number = ph_no.getText().toString().trim();
                String Name = name.getText().toString().trim();
                String EmailID = Email_id.getText().toString().trim();
                String Pass = pwd.getText().toString().trim();
                String date =mDisplayDate.getText().toString().trim();


                Map<String, String> dataMap = new HashMap<>();
                dataMap.put("Name", Name);
                dataMap.put("Email_id", EmailID);
                dataMap.put("password", Pass);
                dataMap.put("PhonNumber", number);
                dataMap.put("Gender",gender);
                dataMap.put("Date",date);
                mDatabase.child(Name).setValue(dataMap);
                Intent intent =new Intent(Genaral_detailsActivity.this,DetailsActivity.class);
                startActivity(intent);
               // Toast.makeText(Genaral_detailsActivity.this,radioSexButton.getText(),Toast.LENGTH_SHORT).show();
            }
        });

    }

/*
    public void RadioButtonClicked(View view) {

//This variable will store whether the user was male or female
        String userGender="";
// Check that the button is  now checked?
        boolean checked = ((RadioButton) view).isChecked();

// Check which radio button was clicked
        switch(view.getId()) {
            case R.id.female_rb:
                if (checked)
                    userGender = "female";
                break;
            case R.id.male_rb:
                if (checked)
                    userGender = "male";
                break;
        }
        HashMap<String,String> dataMap =new HashMap<>();
        dataMap.put("Gender",userGender);
        mDatabase.push().setValue(dataMap);

    }*/
}
