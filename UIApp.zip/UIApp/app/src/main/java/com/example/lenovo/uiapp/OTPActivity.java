package com.example.lenovo.uiapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class OTPActivity extends AppCompatActivity {



    public static final String Name2_extra="Name2";
    public static final String Email2_extra="Email_id2";
    public static final String Pho_no2_extra="phone_number2";
    public static final String Password2_extra="password2";
    String name,Emailid,pho_no,password;
    String verificationId;
    private FirebaseAuth mAuth ;
    private ImageButton icon ,send;
    private PinEntryEditText editText ;
    public ProgressDialog progressDialog;
    private EditText newPhonenumber;
    private TextView pho_no_TV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        Toolbar toolbar;
        toolbar = findViewById(R.id.verification_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("SMS Verification");

        mAuth = FirebaseAuth.getInstance();
        //progressBar = findViewById(R.id.Loader);
        icon = findViewById(R.id.imageButon_change);
        send = findViewById(R.id.imageButon_send);
        newPhonenumber =(EditText)findViewById(R.id.new_phone);
        pho_no_TV =findViewById(R.id.this_phone);
        final Intent intent = getIntent();
        name = intent.getStringExtra(SignupActivity.Name_extra);
        Emailid = intent.getStringExtra(SignupActivity.Email_extra);
        password = intent.getStringExtra(SignupActivity.Password_extra);
        pho_no = intent.getStringExtra(SignupActivity.Pho_no_extra);
        Bundle bd = intent.getExtras();
        if(bd != null)
        {
            String getName = (String) bd.get(SignupActivity.Pho_no_extra);
            pho_no_TV.setText(getName);
        }
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pho_no_TV.setVisibility(View.GONE);
                newPhonenumber.setVisibility(View.VISIBLE);
                icon.setVisibility(View.GONE);
                send.setVisibility(View.VISIBLE);
                newPhonenumber.setText(pho_no_TV.getText().toString());
            }
        });

        send .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                progressDialog.setMessage("Please wait.......");
  //              progressDialog.show();
                Intent intent1 = new Intent(OTPActivity.this,OTPActivity.class);
                startActivity(intent1);
            }
        });
        editText =findViewById(R.id.txt_pin_entry);
        String phoneNumber = getIntent().getStringExtra(SignupActivity.Pho_no_extra);
        SendverificationCode(phoneNumber);

        findViewById(R.id.verify_Otp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              String code =editText.getText().toString().trim();
                if(code.isEmpty()|| code.length()<6){
                    editText.setError("Enter code...");
                    editText .requestFocus();
                    return;
                }


                verifycode(code);

            }
        });
    }
    private void verifycode(String code){
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId,code);
        SignInWithCredential(credential);


    }

    private void SignInWithCredential(PhoneAuthCredential credential) {

        mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Intent intent =new Intent(OTPActivity.this,Genaral_detailsActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                   // progressDialog.setMessage("Please Wait.....");
                    //progressDialog.show();

                    //Intent i =new Intent(OTPActivity.this,Genaral_detailsActivity.class);
                    intent.putExtra(Name2_extra,name);
                    intent.putExtra(Email2_extra,Emailid);
                    intent.putExtra(Pho_no2_extra,pho_no);
                    intent.putExtra(Password2_extra,password);
                    startActivity(intent);
                   // startActivity(i);
                }
                else {
                    Toast.makeText(OTPActivity.this,task.getException().getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void SendverificationCode(String number) {

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+91" + number,
                30,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallbacks);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks

            mCallbacks =new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationId =s;
        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code =phoneAuthCredential.getSmsCode();
            if(code !=null){
                editText.setText(code);
                verifycode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(OTPActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
        }
    };

}
